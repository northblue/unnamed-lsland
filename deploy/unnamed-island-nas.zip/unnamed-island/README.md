# 无名岛绿联配置包

先停止 Web 并完成旧岛导入。LAN 模板为 http://192.168.4.82:3080，更新现有 unnamed-island 项目，保留已填写的 DATABASE_URL，不创建第二个 Web。基础模板不映射端口；tools 默认只查询 status。镜像已发布且匿名可拉取，版本见 release.json。存档包独立提供，不包含在本配置包。详见 LAN.md / MIGRATION.md / DEPLOY.md。
