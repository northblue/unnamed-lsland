# 无名岛绿联配置包

镜像已发布，具体版本见 release.json。先在 UGREEN 新建独立 unnamed-island 项目并导入 Web Compose，取消立即运行。DATABASE_URL 在 NAS 私下填写。当前无宿主端口 / Tunnel，存档导入与访问保护尚待完成，不要直接公开上线。维护 Compose 默认仅查询 status 后退出。详见 DEPLOY.md。
